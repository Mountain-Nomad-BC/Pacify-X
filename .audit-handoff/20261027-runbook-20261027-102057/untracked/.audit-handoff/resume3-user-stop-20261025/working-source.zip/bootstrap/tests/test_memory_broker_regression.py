from __future__ import annotations

from datetime import datetime, timedelta, timezone
import unittest

from runtime.memory_broker import (
    build_memory_query_plan,
    materialize_memory_context,
    validate_memory_query_plan,
)
from runtime.memory_fabric import MemoryRecord


NOW = datetime(2026, 9, 5, tzinfo=timezone.utc)


def _record(memory_id: str, **changes: object) -> MemoryRecord:
    values = {
        "memory_id": memory_id, "workspace_id": "workspace", "project_id": "project",
        "owner_id": "actor", "session_id": "session", "lease_id": "lease",
        "title": "Decision", "memory_type": "decision", "summary": "Use bounded proof",
        "source_artifact": "evidence.json", "source_sha256": "a" * 64,
        "evidence_locator": "evidence:one", "epistemic_status": "observation",
        "confidence": 0.9, "confidence_method": "direct", "classification": "internal",
        "acl": ("project", "actor"), "observed_at": NOW, "effective_at": NOW,
        "certification_status": "certified", "retrieval_enabled": True, "layer": "L1",
        "visibility": "project", "priority": 80,
    }
    values.update(changes)
    return MemoryRecord(**values)


def _plan(**changes):
    values = {
        "project_id": "project", "subject_id": "task", "actor_id": "actor",
        "agent_id": "agent", "binding_ids": ("memory:one",),
        "memory_classes": ("decision",), "tiers": ("L1",), "max_items": 2,
        "max_bytes": 4096, "max_tokens": 1024, "trust_floor": 0.8,
        "max_age_seconds": 3600, "conflict_policy": "quarantine",
        "provenance_required": True, "writeback_policy": "deny",
        "source_revision": "source-1", "dependency_revisions": {"memory": "revision-1"},
    }
    values.update(changes)
    return build_memory_query_plan(**values)


class PXAUD069_NonFiniteBudgetRejected(unittest.TestCase):
    """PX-AUD-069: non-finite memory query limits admit stale records and invalid budgets."""

    def test_nonfinite_max_items_rejected(self) -> None:
        with self.assertRaises(ValueError) as ctx:
            _plan(max_items=float("inf"))
        self.assertIn("max_items must be a positive integer", str(ctx.exception))

    def test_bool_max_bytes_rejected(self) -> None:
        with self.assertRaises(ValueError) as ctx:
            _plan(max_bytes=True)
        self.assertIn("max_bytes must be a positive integer", str(ctx.exception))

    def test_trust_floor_bool_rejected(self) -> None:
        with self.assertRaises(ValueError) as ctx:
            _plan(trust_floor=True)
        self.assertIn("trust_floor must be a finite number between zero and one", str(ctx.exception))

    def test_trust_floor_nan_rejected(self) -> None:
        with self.assertRaises(ValueError) as ctx:
            _plan(trust_floor=float("nan"))
        self.assertIn("trust_floor must be a finite number between zero and one", str(ctx.exception))


class PXAUD070_InvalidConfidenceQuarantined(unittest.TestCase):
    """PX-AUD-070: broker admits invalid non-finite MemoryRecord confidence."""

    def test_bool_confidence_quarantined(self) -> None:
        result = materialize_memory_context(
            _plan(), [_record("memory:one", confidence=True)], now_utc=NOW
        )
        self.assertFalse(result["eligible"])
        self.assertIn("memory_invalid_confidence:memory:one", result["quarantined"])

    def test_nan_confidence_quarantined(self) -> None:
        result = materialize_memory_context(
            _plan(), [_record("memory:one", confidence=float("nan"))], now_utc=NOW
        )
        self.assertFalse(result["eligible"])
        self.assertIn("memory_invalid_confidence:memory:one", result["quarantined"])

    def test_inf_confidence_quarantined(self) -> None:
        result = materialize_memory_context(
            _plan(), [_record("memory:one", confidence=float("inf"))], now_utc=NOW
        )
        self.assertFalse(result["eligible"])
        self.assertIn("memory_invalid_confidence:memory:one", result["quarantined"])

    def test_confidence_out_of_range_quarantined(self) -> None:
        result = materialize_memory_context(
            _plan(), [_record("memory:one", confidence=1.5)], now_utc=NOW
        )
        self.assertFalse(result["eligible"])
        self.assertIn("memory_invalid_confidence:memory:one", result["quarantined"])


class PXAUD073_SearchLimitBounded(unittest.TestCase):
    """PX-AUD-073: MemoryVault.search negative result limit bypasses intended cap."""

    def test_negative_limit_rejected(self) -> None:
        import tempfile
        from pathlib import Path
        from runtime.memory_vault import MemoryVault

        with tempfile.TemporaryDirectory() as directory:
            vault = MemoryVault(Path(directory), workspace_id="wsp", project_id="prj")
            with self.assertRaises(ValueError) as ctx:
                vault.search("query", actor_id="agent", limit=-1)
            self.assertIn("memory search limit must be an integer", str(ctx.exception))

    def test_limit_above_cap_rejected(self) -> None:
        import tempfile
        from pathlib import Path
        from runtime.memory_vault import MemoryVault

        with tempfile.TemporaryDirectory() as directory:
            vault = MemoryVault(Path(directory), workspace_id="wsp", project_id="prj")
            with self.assertRaises(ValueError) as ctx:
                vault.search("query", actor_id="agent", limit=99999)
            self.assertIn("memory search limit must be an integer", str(ctx.exception))

    def test_bool_limit_rejected(self) -> None:
        import tempfile
        from pathlib import Path
        from runtime.memory_vault import MemoryVault

        with tempfile.TemporaryDirectory() as directory:
            vault = MemoryVault(Path(directory), workspace_id="wsp", project_id="prj")
            with self.assertRaises(ValueError) as ctx:
                vault.search("query", actor_id="agent", limit=True)
            self.assertIn("memory search limit must be an integer", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
