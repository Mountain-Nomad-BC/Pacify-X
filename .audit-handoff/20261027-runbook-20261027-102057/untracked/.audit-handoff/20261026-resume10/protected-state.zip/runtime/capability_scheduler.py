"""Deterministic, observe-only capability scheduling and recovery planning."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
import json
import math
from typing import Any, Mapping
from pathlib import Path


NETWORK_RANK = {"none": 0, "local": 1, "private_remote": 2, "external": 3}
DEFAULT_WEIGHTS = {
    "priority": 0.34,
    "deadline_pressure": 0.20,
    "dependency_unblock": 0.16,
    "aging": 0.10,
    "success_rate": 0.08,
    "quality": 0.07,
    "cost_efficiency": 0.05,
}


def _hash(value: object) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


@dataclass(slots=True)
class Resources:
    cpu_cores: float = 0.0
    ram_gb: float = 0.0
    gpu_count: int = 0
    vram_gb: float = 0.0
    disk_gb: float = 0.0
    network: str = "none"

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any] | None) -> "Resources":
        value = value or {}
        fields = cls.__dataclass_fields__
        numeric_fields = ("cpu_cores", "ram_gb", "gpu_count", "vram_gb", "disk_gb")
        result: dict[str, Any] = {}
        for name, field in fields.items():
            val = value.get(name, field.default)
            if name in numeric_fields:
                if isinstance(val, bool):
                    raise ValueError(f"{name} must be a non-negative number, not bool")
                try:
                    num = float(val)
                except (TypeError, ValueError):
                    raise ValueError(f"{name} must be a non-negative number")
                if num < 0:
                    raise ValueError(f"{name} must be non-negative")
                result[name] = int(num) if name == "gpu_count" else num
            else:
                result[name] = val
        return cls(**result)

    def fits(self, requested: "Resources") -> bool:
        return (
            self.cpu_cores >= requested.cpu_cores
            and self.ram_gb >= requested.ram_gb
            and self.gpu_count >= requested.gpu_count
            and self.vram_gb >= requested.vram_gb
            and self.disk_gb >= requested.disk_gb
            and NETWORK_RANK.get(self.network, -1)
            >= NETWORK_RANK.get(requested.network, 99)
        )

    def consume(self, requested: "Resources") -> None:
        for name in ("cpu_cores", "ram_gb", "gpu_count", "vram_gb", "disk_gb"):
            setattr(self, name, getattr(self, name) - getattr(requested, name))

    def release(self, requested: "Resources") -> None:
        for name in ("cpu_cores", "ram_gb", "gpu_count", "vram_gb", "disk_gb"):
            setattr(self, name, getattr(self, name) + getattr(requested, name))

    def record(self) -> dict[str, Any]:
        return {name: getattr(self, name) for name in self.__dataclass_fields__}


@dataclass(slots=True)
class Task:
    id: str
    capability: str
    priority: int = 500
    state: str = "pending"
    dependencies: list[str] = field(default_factory=list)
    estimated_seconds: float = 1.0
    resources: Resources = field(default_factory=Resources)
    acceptance: dict[str, Any] = field(default_factory=dict)
    deadline: str | None = None
    risk: str = "low"
    approval_required: bool = False
    approved: bool = False
    idempotency_key: str | None = None
    compensation: str | None = None
    alternatives: list[str] = field(default_factory=list)
    budget: dict[str, Any] = field(default_factory=dict)
    attempt: int = 1
    privacy: str = "normal"
    created_index: int = 0

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "Task":
        fields = cls.__dataclass_fields__
        values = {
            name: value[name]
            for name in fields
            if name in value and name not in {"resources", "created_index"}
        }
        values["resources"] = Resources.from_mapping(value.get("resources"))
        return cls(**values)


class Scheduler:
    """Plans and simulates; it never invokes an executor or mutates canonical state."""

    def __init__(
        self,
        resources: Resources,
        policy: Mapping[str, Any] | None = None,
        *,
        now: datetime | None = None,
    ):
        self.total = resources
        self.available = Resources.from_mapping(resources.record())
        self.policy = dict(policy or {})
        self.now = now or datetime(2000, 1, 1, tzinfo=timezone.utc)
        self.tasks: dict[str, Task] = {}
        self.completed: set[str] = set()
        self.failed: set[str] = set()
        self.events: list[dict[str, Any]] = []
        self._counter = 0
        self._dependents: dict[str, set[str]] = {}

    def add(self, task: Task) -> None:
        if task.id in self.tasks:
            raise ValueError(f"duplicate task id: {task.id}")
        if not task.id or not task.capability:
            raise ValueError("task id and capability are required")
        if not 0 <= int(task.priority) <= 1000:
            raise ValueError(f"priority outside 0..1000: {task.id}")
        self._counter += 1
        task.created_index = self._counter
        self.tasks[task.id] = task
        for dependency in task.dependencies:
            self._dependents.setdefault(dependency, set()).add(task.id)
        self.events.append({"event": "task_added", "task_id": task.id})

    def validate_dag(self) -> None:
        visiting: set[str] = set()
        visited: set[str] = set()

        for start in sorted(self.tasks):
            if start in visited:
                continue
            stack = [(start, iter(sorted(self.tasks[start].dependencies)))]
            visiting.add(start)
            while stack:
                node, deps_iter = stack[-1]
                advanced = False
                for dep in deps_iter:
                    if dep not in self.tasks:
                        raise ValueError(f"missing dependency {dep} for {node}")
                    if dep in visiting:
                        raise ValueError(f"dependency cycle at {dep}")
                    if dep not in visited:
                        visiting.add(dep)
                        stack.append((dep, iter(sorted(self.tasks[dep].dependencies))))
                        advanced = True
                        break
                if not advanced:
                    visiting.discard(node)
                    visited.add(node)
                    stack.pop()

    def eligible(self, task: Task) -> tuple[bool, list[str]]:
        reasons: list[str] = []
        if task.state not in {"pending", "ready"}:
            reasons.append("state_not_schedulable")
        if any(dependency not in self.completed for dependency in task.dependencies):
            reasons.append("dependencies_incomplete")
        if task.approval_required and not task.approved:
            reasons.append("approval_required")
        if not self.available.fits(task.resources):
            reasons.append("resource_unavailable")
        if task.risk in {"high", "critical"} and not task.acceptance:
            reasons.append("acceptance_missing")
        if (
            task.privacy in {"restricted", "secret"}
            and task.resources.network == "external"
        ):
            reasons.append("privacy_policy_denied")
        if (
            self.policy.get("external_network") == "deny"
            and task.resources.network == "external"
        ):
            reasons.append("egress_policy_denied")
        maximum_cost = task.budget.get("maximum_cost")
        estimated_cost = task.budget.get("estimated_cost")
        if "maximum_cost" in task.budget or "estimated_cost" in task.budget:
            try:
                # A declared bound is complete, finite and nonnegative. Coercing
                # strings/bools or treating an absent observation as unbounded
                # can admit work with no usable cost evidence.
                valid = (
                    type(maximum_cost) in (int, float)
                    and type(estimated_cost) in (int, float)
                    and math.isfinite(maximum_cost)
                    and math.isfinite(estimated_cost)
                    and maximum_cost >= 0 and estimated_cost >= 0
                    and estimated_cost <= maximum_cost
                )
            except OverflowError:
                valid = False
            if not valid:
                reasons.append("budget_exhausted")
        if task.attempt > 1 and not task.idempotency_key and not task.compensation:
            reasons.append("retry_requires_idempotency_or_compensation")
        return not reasons, sorted(reasons)

    def score(self, task: Task) -> tuple[float, dict[str, float]]:
        downstream = sum(
            1
            for candidate_id in self._dependents.get(task.id, ())
            if self.tasks[candidate_id].state in {"pending", "ready"}
        )
        maximum_downstream = max(1, len(self.tasks) - 1)
        deadline_pressure = 0.0
        if task.deadline:
            try:
                deadline = datetime.fromisoformat(task.deadline.replace("Z", "+00:00"))
                remaining = (deadline - self.now).total_seconds()
                deadline_pressure = _clamp(
                    1.0 - remaining / max(task.estimated_seconds * 10.0, 1.0)
                )
            except ValueError:
                deadline_pressure = 0.0
        factors = {
            "priority": _clamp(task.priority / 1000.0),
            "deadline_pressure": deadline_pressure,
            "dependency_unblock": _clamp(downstream / maximum_downstream),
            "aging": _clamp(
                (self._counter - task.created_index) / max(1, self._counter)
            ),
            "success_rate": _clamp(float(task.acceptance.get("expected_success", 0.5))),
            "quality": _clamp(float(task.acceptance.get("required_quality", 0.5))),
            "cost_efficiency": _clamp(float(task.budget.get("cost_efficiency", 0.5))),
        }
        weights = dict(DEFAULT_WEIGHTS)
        weights.update(self.policy.get("weights", {}))
        total_weight = sum(max(0.0, float(value)) for value in weights.values()) or 1.0
        score = (
            sum(
                factors[name] * max(0.0, float(weights.get(name, 0.0)))
                for name in factors
            )
            / total_weight
        )
        return round(score, 8), {
            name: round(value, 8) for name, value in factors.items()
        }

    def next_task(
        self,
    ) -> tuple[Task | None, dict[str, list[str]], dict[str, Any] | None]:
        eligible: list[tuple[float, int, str, dict[str, float]]] = []
        blocked: dict[str, list[str]] = {}
        for task in self.tasks.values():
            accepted, reasons = self.eligible(task)
            if accepted:
                score, factors = self.score(task)
                eligible.append((-score, task.created_index, task.id, factors))
            elif task.state in {"pending", "ready"}:
                blocked[task.id] = reasons
        if not eligible:
            return None, blocked, None
        eligible.sort()
        negated, _, task_id, factors = eligible[0]
        return self.tasks[task_id], blocked, {"score": -negated, "factors": factors}

    def simulate(self) -> dict[str, Any]:
        self.validate_dag()
        decisions: list[dict[str, Any]] = []
        while len(self.completed | self.failed) < len(self.tasks):
            task, blocked, score = self.next_task()
            if task is None:
                decisions.append({"event": "stalled", "blocked": blocked})
                break
            self.available.consume(task.resources)
            task.state = "running"
            dispatch = {
                "event": "would_dispatch",
                "task_id": task.id,
                **(score or {}),
                "resources": task.resources.record(),
                "idempotency_key": task.idempotency_key,
            }
            decisions.append(dispatch)
            self.events.append(dispatch)
            self.available.release(task.resources)
            evidence = {
                "simulation": True,
                "acceptance_preserved": True,
                "executor_not_invoked": True,
            }
            task.state = "succeeded"
            self.completed.add(task.id)
            finish = {
                "event": "simulated_completion",
                "task_id": task.id,
                "evidence": evidence,
            }
            decisions.append(finish)
            self.events.append(finish)
        stalled = len(self.completed | self.failed) < len(self.tasks)
        return {
            "valid": not stalled,
            "observe_only": True,
            "completed": sorted(self.completed),
            "failed": sorted(self.failed),
            "events": decisions,
            "stalled": stalled,
            "decision_hash": _hash(self.events),
            "execution_authority": "none; dispatch events are plans only",
        }


def simulate_schedule(payload: Mapping[str, Any]) -> dict[str, Any]:
    workload = payload.get("workload", payload)
    tasks = workload.get("tasks") if isinstance(workload, Mapping) else None
    if not isinstance(tasks, list):
        return {"valid": False, "errors": ["workload.tasks must be a list"]}
    now_value = payload.get("now", "2000-01-01T00:00:00Z")
    try:
        now = datetime.fromisoformat(str(now_value).replace("Z", "+00:00"))
        scheduler = Scheduler(
            Resources.from_mapping(payload.get("resources", {})),
            payload.get("policy", {}),
            now=now,
        )
        for value in tasks:
            if not isinstance(value, Mapping):
                raise ValueError("every task must be an object")
            scheduler.add(Task.from_mapping(value))
        return scheduler.simulate()
    except (KeyError, TypeError, ValueError) as error:
        return {"valid": False, "observe_only": True, "errors": [str(error)]}


def integration_healthcheck() -> dict[str, Any]:
    result = simulate_schedule(
        {
            "resources": {"cpu_cores": 1},
            "workload": {
                "tasks": [
                    {
                        "id": "a",
                        "capability": "noop",
                        "priority": 1,
                        "resources": {"cpu_cores": 1},
                        "acceptance": {},
                    }
                ]
            },
        }
    )
    return {"valid": result.get("valid") is True and result.get("observe_only") is True}


def _load(root: Path, relative: str) -> dict[str, Any]:
    return json.loads((root / relative).read_text(encoding="utf-8"))


def list_scheduling_capabilities(root: Path) -> dict[str, Any]:
    records = _load(root, "registry/scheduling_capability_owners.json")["records"]
    return {
        "valid": True,
        "metadata_only": True,
        "count": len(records),
        "records": records,
    }


def describe_scheduling_capability(root: Path, capability_id: str) -> dict[str, Any]:
    index = _load(root, "registry/scheduling_capabilities.json")["capabilities"]
    contract = next((item for item in index if item["id"] == capability_id), None)
    if contract is None:
        return {
            "valid": False,
            "errors": [f"unknown scheduling capability: {capability_id}"],
        }
    return {
        "valid": True,
        "owner": "orchestrate-capability-scheduling",
        "contract": contract,
    }


def validate_scheduling_layer(root: Path) -> dict[str, Any]:
    capabilities = _load(root, "registry/scheduling_capabilities.json").get(
        "capabilities", []
    )
    owners = _load(root, "registry/scheduling_capability_owners.json").get(
        "records", []
    )
    workflows = _load(root, "orchestration/workflows/capability-scheduling.yaml").get(
        "workflows", []
    )
    policies = _load(root, "registry/scheduling_policies.json").get("policies", [])
    schemas = list((root / "contracts" / "scheduling").glob("*.json"))
    actual = {
        "capabilities": len(capabilities),
        "owners": len(owners),
        "workflows": len(workflows),
        "policies": len(policies),
        "schemas": len(schemas),
    }
    expected = {
        "capabilities": 30,
        "owners": 30,
        "workflows": 5,
        "policies": 3,
        "schemas": 8,
    }
    errors = [
        f"{name} denominator mismatch: {actual[name]} != {count}"
        for name, count in expected.items()
        if actual[name] != count
    ]
    if {item["id"] for item in capabilities} != {item["id"] for item in owners}:
        errors.append("scheduling capability owner projection is not bijective")
    return {
        "valid": not errors,
        "counts": actual,
        "observe_only": True,
        "errors": errors,
    }


def model_route_capacity_snapshot(
    scheduler: Scheduler,
    *,
    queue_depth: int,
    max_queue_depth: int,
    concurrent_slots_total: int,
    concurrent_slots_available: int,
    exclusive_model_id: str | None = None,
):
    """Project scheduler-owned resource pressure into the model routing plane.

    The returned snapshot is observational.  It does not reserve resources or
    create a lease; model execution still goes through the owning scheduler and
    model-runtime authorities.
    """
    from .model_capacity import ModelCapacitySnapshot

    if type(scheduler) is not Scheduler:
        raise ValueError("typed Scheduler is required")
    total = scheduler.total
    available = scheduler.available
    return ModelCapacitySnapshot(
        cpu_cores_total=float(total.cpu_cores),
        cpu_cores_available=float(available.cpu_cores),
        ram_gb_total=float(total.ram_gb),
        ram_gb_available=float(available.ram_gb),
        vram_gb_total=float(total.vram_gb),
        vram_gb_available=float(available.vram_gb),
        concurrent_slots_total=concurrent_slots_total,
        concurrent_slots_available=concurrent_slots_available,
        queue_depth=queue_depth,
        max_queue_depth=max_queue_depth,
        exclusive_model_id=exclusive_model_id,
        source_sha256=_hash({
            "scheduler_total": total.record(),
            "scheduler_available": available.record(),
            "policy": scheduler.policy,
        }),
    )


def durable_job_receipt(
    task: Task,
    *,
    permission_snapshot: Mapping[str, Any],
    authority_revision: str,
    fabric_generation: str | None = None,
    retrieval_generation: str | None = None,
    dry_run: bool = False,
    max_retries: int = 0,
):
    """Freeze scheduler admission context into the standard immutable job receipt.

    The receipt is evidence only.  It does not enqueue or authorize the task.
    """
    from .job_receipt import JobReceipt

    if type(task) is not Task:
        raise ValueError("typed Task required")
    request = {
        "id": task.id,
        "capability": task.capability,
        "priority": task.priority,
        "dependencies": sorted(task.dependencies),
        "resources": task.resources.record(),
        "acceptance": task.acceptance,
        "deadline": task.deadline,
        "risk": task.risk,
        "idempotency_key": task.idempotency_key,
        "budget": task.budget,
        "privacy": task.privacy,
    }
    return JobReceipt.create(
        job_id=task.id,
        operation_id=task.capability,
        request=request,
        permission_snapshot=permission_snapshot,
        authority_revision=authority_revision,
        fabric_generation=fabric_generation,
        retrieval_generation=retrieval_generation,
        dry_run=dry_run,
        max_retries=max_retries,
    )
