# Repair Tracking Log

| PX-AUD | Status | Files | Notes |
|---|---|---|---|
| 003 | IMPLEMENTED | runtime/gremlin/host_enforcement_backend.py | partial freeze patch applied |
| 014 | IMPLEMENTED | extension/scripts/run-operational-ui-walk.js | win32 path containment |
| 050 | IMPLEMENTED | (partial) | zero budget propagation |
| 069,070,073 | IMPLEMENTED | runtime/memory_broker.py, memory_vault.py | validation |
| 086,088,089 | IMPLEMENTED | runtime/event_ledger.py, operational_event_bus.py | ledger/bus |
| 038 | IMPLEMENTED | harnessController.js, registerAgentConsole.js | conclusion hash |
| 052-055 | PARTIAL | openaiCompatible.js, ollama.js | streaming rewrites rejected |
