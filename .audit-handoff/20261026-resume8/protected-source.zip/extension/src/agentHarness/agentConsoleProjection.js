'use strict';

function safeContext(context) {
  if (!context) return null;
  return { contextId: context.contextId, budgetTokens: context.budgetTokens, suppliedTokens: context.suppliedTokens, consideredCount: context.consideredCount, selectedCount: context.selectedCount,
    refs: (context.refs || []).map(r => ({ refId: r.refId, kind: r.kind, label: r.label, source: r.source, tokenEstimate: r.tokenEstimate, authority: r.authority, freshAt: r.freshAt, sha256: r.sha256 })) };
}

function buildAgentConsoleProjection(state) {
  return {
    schemaVersion: 'px.agent-console-projection/1.0', generatedAt: new Date().toISOString(),
    task: state.activeTask, run: state.activeRun,
    workers: (state.workers || []).map(w => ({ workerId: w.workerId, providerId: w.providerId, modelId: w.modelId, displayName: w.displayName, costClass: w.costClass, locality: w.locality, capabilities: w.capabilities, enabled: w.enabled, health: w.health })),
    librarian: state.librarian,
    context: safeContext(state.context),
    route: state.route ? { reason: state.route.reason, selectedWorkerId: state.route.selected?.workerId || null, evaluated: (state.route.evaluated || []).map(r => ({ workerId: r.worker.workerId, displayName: r.worker.displayName, costClass: r.worker.costClass, admitted: r.admitted, reasons: r.reasons, score: r.score })) } : null,
    budget: state.budget,
    evidence: state.evidence || [],
    events: (state.events || []).map(event => ({ ...event, payload: redactEventPayload(event) }))
  };
}

const SECRET_KEY = /secret|api.?key|authorization|credential/i;
const MAX_REDACT_DEPTH = 8;
const MAX_REDACT_BYTES = 1_000_000;

function redactValue(value, depth) {
  if (depth > MAX_REDACT_DEPTH) return '[redacted]';
  if (value === null || value === undefined || typeof value === 'boolean' || typeof value === 'number') return value;
  if (typeof value === 'string') {
    if (Buffer.byteLength(value, 'utf8') > 50_000) return value.slice(0, 50_000) + '...[truncated]';
    return value;
  }
  if (Array.isArray(value)) {
    return value.map(item => redactValue(item, depth + 1));
  }
  if (typeof value === 'object') {
    const out = {};
    let totalBytes = 0;
    for (const key of Object.keys(value)) {
      const isSecret = SECRET_KEY.test(key);
      const redacted = isSecret ? '[redacted]' : redactValue(value[key], depth + 1);
      const entry = isSecret ? `'${key}':${JSON.stringify(redacted)}` : `'${key}':${JSON.stringify(redacted)}`;
      totalBytes += Buffer.byteLength(entry, 'utf8');
      if (totalBytes > MAX_REDACT_BYTES) {
        out[key] = '[redacted]';
        continue;
      }
      out[key] = redacted;
    }
    return out;
  }
  return '[redacted]';
}

function redactEventPayload(event) {
  const payload = { ...(event.payload || {}) };
  if (event.type === 'worker.completed' && typeof payload.text === 'string') payload.text = payload.text.slice(0, 120000);
  for (const key of Object.keys(payload)) {
    if (SECRET_KEY.test(key)) {
      payload[key] = '[redacted]';
    } else {
      payload[key] = redactValue(payload[key], 0);
    }
  }
  return payload;
}

module.exports = { buildAgentConsoleProjection };
