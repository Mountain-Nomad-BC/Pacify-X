"""Governed entry point for the real Windows Job-containment operating probe.

The operating evidence itself is produced by ``scripts/probe_native_job_containment.py``
and must stay a real child-process experiment, not a unit assertion. The governed
section parser only admits registered runner forms (``python -m pytest`` / ``node --test``),
so this module runs the probe as its own subprocess with the same bounded timeout the
section declares, and asserts on the probe's own machine-readable verdict.

Windows-only: on a host without the native Job API the probe cannot make a claim.
That is reported as a skip with an explicit reason, never as a pass.
"""

from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
PROBE = ROOT / "scripts" / "probe_native_job_containment.py"
# Matches the section's own timeout_seconds (200) with a small margin so the
# outer guard fires only if the probe itself overruns its declared bound.
PROBE_TIMEOUT_SECONDS = 200


def test_native_job_containment_operating_probe():
    if sys.platform != "win32":
        pytest.skip("Windows Job Object operating probe is unavailable on this host")
    assert PROBE.is_file(), f"operating probe is missing: {PROBE}"
    completed = subprocess.run(
        [sys.executable, str(PROBE)],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        timeout=PROBE_TIMEOUT_SECONDS,
        check=False,
    )
    combined = f"{completed.stdout}\n{completed.stderr}".strip()
    assert completed.returncode == 0, f"probe failed rc={completed.returncode}:\n{combined}"
    verdict = None
    for line in reversed(completed.stdout.splitlines()):
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            try:
                candidate = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(candidate, dict):
                verdict = candidate
                break
    assert verdict is not None, f"probe emitted no JSON verdict:\n{combined}"
    # The probe's own retained verdict must agree with its exit status. We do not
    # reinterpret its thresholds here; a disagreement is a custody defect.
    if "valid" in verdict:
        assert verdict["valid"] is True, f"probe verdict not valid:\n{combined}"
    if "passed" in verdict:
        assert verdict["passed"] is True, f"probe verdict not passed:\n{combined}"
