"""Build the explicit one-record-per-contract ownership registry."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


ROOT_OWNERS = {
    "agent_handoff_packet.schema.json": (
        "runtime/agent_handoff.py",
        ["runtime/agent_handoff.py", "runtime/agent_runtime.py"],
        "agent_runtime_boundary",
        ["tests/test_agent_handoff.py", "tests/test_agent_governed_integration.py"],
    ),
    "capability_semantic_profile.schema.json": (
        "runtime/capability_semantics.py",
        ["runtime/capability_semantics.py", "runtime/semantic_index.py"],
        "runtime_enforced",
        ["tests/test_capability_semantics.py"],
    ),
    "foundry_candidate_skill.schema.json": (
        "runtime/foundry_studio_bridge.py",
        ["runtime/foundry_studio_bridge.py", "runtime/knowledge_foundry.py"],
        "runtime_enforced",
        ["tests/test_foundry_studio_bridge.py"],
    ),
    "memory_query_plan.schema.json": (
        "runtime/memory_broker.py",
        ["runtime/memory_broker.py", "runtime/agent_runtime.py"],
        "memory_lifecycle_runtime_boundary",
        ["tests/test_memory_broker.py", "tests/test_agent_governed_integration.py"],
    ),
    "model_attachment.schema.json": (
        "runtime/model_attachment.py",
        ["runtime/model_attachment.py", "runtime/execution_placement.py"],
        "runtime_enforced",
        ["tests/test_model_attachment.py", "tests/test_execution_placement.py"],
    ),
    "provider_execution_policy.schema.json": (
        "runtime/provider_gateway.py",
        ["runtime/provider_gateway.py", "extension/src/providerExecutionPolicy.js"],
        "runtime_enforced",
        ["tests/test_provider_gateway.py", "extension/tests/provider-execution-policy.test.js"],
    ),
    "task_execution_plan.schema.json": (
        "runtime/task_execution_plan.py",
        ["runtime/task_execution_plan.py", "runtime/capability_routing.py"],
        "runtime_enforced",
        ["tests/test_task_execution_plan.py"],
    ),
    "local-model-runtime.schema.json": (
        "runtime/local_model_runtime.py",
        ["runtime/local_model_runtime.py"],
        "local_model_lifecycle_runtime_boundary",
        ["tests/test_local_model_runtime.py"],
    ),
    "assurance-probe.schema.json": (
        "runtime/behavioral_assurance.py",
        ["runtime/behavioral_assurance.py"],
        "runtime_enforced",
        ["tests/test_behavioral_assurance.py"],
    ),
    "benchmark-custody.schema.json": (
        "runtime/benchmark_operations.py",
        ["runtime/benchmark_operations.py"],
        "runtime_enforced",
        ["tests/test_benchmark_operations.py"],
    ),
    "benchmark-execution-profile.schema.json": (
        "runtime/benchmark_operations.py",
        ["runtime/benchmark_operations.py"],
        "runtime_enforced",
        ["tests/test_benchmark_operations.py"],
    ),
    "benchmark-failure.schema.json": (
        "runtime/benchmark_operations.py",
        ["runtime/benchmark_operations.py"],
        "runtime_enforced",
        ["tests/test_benchmark_operations.py"],
    ),
    "coverage-frontier-event.schema.json": (
        "runtime/behavioral_assurance.py",
        ["runtime/behavioral_assurance.py"],
        "runtime_enforced",
        ["tests/test_behavioral_assurance.py"],
    ),
    "evaluation-lineage.schema.json": (
        "runtime/behavioral_assurance.py",
        ["runtime/behavioral_assurance.py"],
        "runtime_enforced",
        ["tests/test_behavioral_assurance.py"],
    ),
    "failure-attribution.schema.json": (
        "runtime/behavioral_assurance.py",
        ["runtime/behavioral_assurance.py"],
        "runtime_enforced",
        ["tests/test_behavioral_assurance.py"],
    ),
    "hardware-equivalence.schema.json": (
        "runtime/hardware_routing.py",
        ["runtime/hardware_routing.py"],
        "runtime_enforced",
        ["tests/test_hardware_routing.py"],
    ),
    "improvement-candidate.schema.json": (
        "runtime/behavioral_assurance.py",
        ["runtime/behavioral_assurance.py"],
        "runtime_enforced",
        ["tests/test_behavioral_assurance.py"],
    ),
    "retry-budget.schema.json": (
        "runtime/benchmark_operations.py",
        ["runtime/benchmark_operations.py"],
        "runtime_enforced",
        ["tests/test_benchmark_operations.py"],
    ),
    "project-impact.schema.json": (
        "runtime/project_impact.py",
        ["runtime/project_impact.py", "runtime/cli.py"],
        "runtime_enforced",
        ["tests/test_project_mapping.py"],
    ),
    "project-map.schema.json": (
        "runtime/project_intelligence.py",
        ["runtime/project_intelligence.py"],
        "runtime_enforced",
        ["tests/test_project_mapping.py"],
    ),
    "authorization-request.schema.json": (
        "runtime/execution_contract.py",
        ["runtime/cli.py"],
        "runtime_enforced",
        ["tests/test_trust_boundaries.py"],
    ),
    "authoritative-skill-contract.schema.json": (
        ".px/skills/govern-operating-kernel/scripts/authoritative_skill_compiler.py",
        [
            ".px/skills/govern-operating-kernel/scripts/authoritative_skill_compiler.py"
        ],
        "runtime_enforced",
        ["tests/test_authoritative_skill_compiler.py"],
    ),
    "builder-contract.schema.json": (
        "builders/common.py",
        ["builders/skill_builder.py", "builders/orchestration_builder.py"],
        "builder_boundary",
        ["tests/test_wave5_builders.py"],
    ),
    "capability-contract.schema.json": (
        "runtime/registry.py",
        ["builders/skill_builder.py"],
        "runtime_registry_boundary",
        ["tests/test_config_and_registry.py"],
    ),
    "candidate-admission-request.schema.json": (
        "runtime/admission_controller.py",
        ["runtime/cli.py"],
        "runtime_enforced",
        ["tests/test_trust_boundaries.py"],
    ),
    "commissioning-questionnaire.schema.json": (
        "runtime/commissioning.py",
        ["runtime/commissioning.py"],
        "runtime_enforced",
        ["tests/test_commissioning_questionnaire.py"],
    ),
    "containment-action.schema.json": (
        "runtime/assurance_controls.py",
        ["runtime/assurance_controls.py"],
        "runtime_control_equivalent",
        ["tests/test_assurance_controls.py"],
    ),
    "evidence-record.schema.json": (
        "runtime/evidence_assembler.py",
        ["runtime/evidence_assembler.py"],
        "runtime_control_equivalent",
        ["tests/test_evidence_assembler.py"],
    ),
    "evidence-reference.schema.json": (
        "runtime/external_evidence.py",
        ["runtime/external_evidence.py"],
        "runtime_enforced",
        ["tests/test_external_evidence.py"],
    ),
    "external-tool-intake.schema.json": (
        "runtime/tool_intake.py",
        ["runtime/tool_intake.py"],
        "runtime_enforced",
        ["tests/test_tool_intake.py"],
    ),
    "engineering-process-record.schema.json": (
        "runtime/process_memory.py",
        ["runtime/process_memory.py"],
        "runtime_enforced",
        ["tests/test_process_memory.py"],
    ),
    "integration-contract.schema.json": (
        "runtime/integration_registry.py",
        ["runtime/integration_registry.py", "registry/integrations.json"],
        "runtime_registry_boundary",
        ["tests/test_retrieval_and_models.py"],
    ),
    "knowledge-source.schema.json": (
        "runtime/retrieval.py",
        ["runtime/retrieval.py"],
        "runtime_control_equivalent",
        ["tests/test_retrieval_and_models.py"],
    ),
    "model-contract.schema.json": (
        "runtime/models.py",
        ["runtime/models.py"],
        "runtime_registry_boundary",
        ["tests/test_retrieval_and_models.py"],
    ),
    "orchestration-contract.schema.json": (
        "runtime/graphs.py",
        ["builders/orchestration_builder.py"],
        "builder_and_registry_boundary",
        ["tests/test_graphs_and_orchestrations.py"],
    ),
    "outcome-verification-request.schema.json": (
        "runtime/outcome_verifier.py",
        ["runtime/cli.py"],
        "runtime_enforced",
        ["tests/test_trust_boundaries.py"],
    ),
    "policy-contract.schema.json": (
        "runtime/execution_contract.py",
        ["runtime/execution_contract.py"],
        "runtime_control_equivalent",
        ["tests/test_execution_contract.py"],
    ),
    "project-management.schema.json": (
        "runtime/project_management.py",
        ["runtime/project_management.py"],
        "runtime_enforced",
        ["tests/test_commissioning_apply.py"],
    ),
    "runtime-assurance.schema.json": (
        "runtime/cognitive_assurance.py",
        ["runtime/cognitive_assurance.py"],
        "runtime_control_equivalent",
        ["tests/test_cognitive_assurance.py"],
    ),
    "skeptical-certification.schema.json": (
        "runtime/assurance_controls.py",
        ["runtime/assurance_controls.py"],
        "runtime_control_equivalent",
        ["tests/test_assurance_controls.py"],
    ),
    "skill-package.schema.json": (
        "runtime/lazy_loader.py",
        ["builders/skill_builder.py"],
        "runtime_registry_boundary",
        ["tests/test_skill_library.py"],
    ),
    "source-capability-audit.schema.json": (
        "runtime/capability_assimilation.py",
        [
            ".px/skills/audit-source-capabilities/scripts/audit_source_capabilities.py"
        ],
        "runtime_registry_boundary",
        [
            "tests/test_capability_assimilation.py",
            "tests/test_capability_mining_skills.py",
        ],
    ),
    "source-intake-event.schema.json": (
        "runtime/intake_lifecycle.py",
        ["runtime/intake_lifecycle.py"],
        "runtime_control_equivalent",
        ["tests/test_intake_lifecycle.py"],
    ),
    "tool-contract.schema.json": (
        "runtime/registry.py",
        ["registry/tools.json"],
        "runtime_registry_boundary",
        ["tests/test_config_and_registry.py"],
    ),
    "trusted-evidence-record.schema.json": (
        "runtime/trusted_evidence.py",
        ["runtime/trusted_evidence.py"],
        "runtime_enforced",
        ["tests/test_trust_boundaries.py"],
    ),
    "ui-context.schema.json": (
        "runtime/classifier.py",
        ["runtime/classifier.py"],
        "runtime_control_equivalent",
        ["tests/test_runtime_wave4.py"],
    ),
    "validation-contract.schema.json": (
        "runtime/outcome_verifier.py",
        ["runtime/outcome_verifier.py"],
        "runtime_control_equivalent",
        ["tests/test_outcome_verifier.py"],
    ),
}

PROJECT_OWNERS = {
    "active-session.schema.json": ("runtime/workspace_manager.py", "runtime_enforced"),
    "agent-memory-provider-certificate.schema.json": (
        "runtime/provider_certification.py",
        "typed_runtime_equivalent",
    ),
    "agent_record.schema.json": (
        "runtime/project_control_plane.py",
        "typed_runtime_equivalent",
    ),
    "capability_record.schema.json": (
        "runtime/project_control_plane.py",
        "typed_runtime_equivalent",
    ),
    "decision_record.schema.json": (
        "runtime/project_control_plane.py",
        "typed_runtime_equivalent",
    ),
    "lock_record.schema.json": ("runtime/file_lock.py", "typed_runtime_equivalent"),
    "memory_note.schema.json": ("runtime/memory_fabric.py", "typed_runtime_equivalent"),
    "orchestration_record.schema.json": (
        "runtime/project_stream_orchestrator.py",
        "typed_runtime_equivalent",
    ),
    "project-scope-envelope.schema.json": (
        "runtime/project_stream_controls.py",
        "runtime_enforced_via_active_session",
    ),
    "project_record.schema.json": (
        "runtime/commissioning.py",
        "typed_runtime_equivalent",
    ),
    "quarantine_record.schema.json": (
        "runtime/project_control_plane.py",
        "typed_runtime_equivalent",
    ),
    "repository_record.schema.json": (
        "runtime/project_control_plane.py",
        "typed_runtime_equivalent",
    ),
    "transfer_package.schema.json": (
        "runtime/project_stream_controls.py",
        "typed_runtime_equivalent",
    ),
    "workflow-request.schema.json": (
        "runtime/workspace_manager.py",
        "runtime_control_equivalent",
    ),
    "workspace-binding.schema.json": (
        "runtime/workspace_manager.py",
        "runtime_enforced",
    ),
    "workspace-registry.schema.json": (
        "runtime/workspace_manager.py",
        "runtime_enforced",
    ),
    "workspace_config.schema.json": (
        "runtime/workspace_manager.py",
        "runtime_enforced",
    ),
    "workstream.schema.json": (
        "runtime/project_control_plane.py",
        "typed_runtime_equivalent",
    ),
    "durable-goal-state.schema.json": ("runtime/durable_state.py", "runtime_enforced"),
}

AGENT_OWNERS = {
    "agency-agent-manifest.schema.json": ["registry/agency_agent_registry.json"],
    "agent-evidence-receipt.schema.json": ["runtime/agent_provider.py"],
    "agent-handoff.schema.json": ["runtime/agent_provider.py"],
    "agent-result.schema.json": ["runtime/agent_provider.py"],
    "agent-route-plan.schema.json": ["runtime/agent_provider.py", "runtime/cli.py"],
    "agent-task-envelope.schema.json": ["runtime/agent_provider.py", "runtime/cli.py"],
    "fleet-readiness.schema.json": ["runtime/agent_fleet_controls.py"],
    "terminal-session-adapter.schema.json": ["runtime/agent_fleet_controls.py"],
}

TRANSCRIPT_OWNERS = {
    "transcript-profile.schema.json": [
        "runtime/transcript_analysis.py",
        "runtime/cli.py",
    ],
    "transcript-source.schema.json": ["runtime/transcript_analysis.py"],
    "transcript-record.schema.json": [
        "runtime/transcript_analysis.py",
        "runtime/cli.py",
    ],
    "transcript-ontology.schema.json": ["runtime/transcript_analysis.py"],
}

MEMORY_OWNERS = {
    "memory-event.schema.json": ["runtime/memory_intelligence.py"],
    "memory-loadout.schema.json": [
        "runtime/memory_intelligence.py",
        "runtime/agent_provider.py",
    ],
    "memory-offload-pointer.schema.json": ["runtime/memory_intelligence.py"],
    "memory-promotion-decision.schema.json": [
        "runtime/memory_intelligence.py",
        "runtime/memory_vault.py",
    ],
    "memory-recall-package.schema.json": ["runtime/memory_intelligence.py"],
    "memory-evaluation-fixture.schema.json": ["runtime/memory_intelligence.py"],
    "memory-remediation-plan.schema.json": ["runtime/memory_remediation.py"],
    "semantic-memory-envelope.schema.json": [
        "runtime/semantic_memory.py",
        "runtime/memory_fabric.py",
        "runtime/memory_intelligence.py",
        "runtime/project_stream_orchestrator.py",
    ],
}

EXTERNAL_CAPABILITY_OWNERS = {
    "external-capability-candidate.schema.json": [
        "runtime/external_capability_provider.py"
    ],
    "selective-stage-plan.schema.json": [
        "runtime/external_capability_provider.py",
        "runtime/cli.py",
    ],
    "hook-decision.schema.json": ["runtime/external_capability_provider.py"],
    "session-snapshot.schema.json": ["runtime/external_capability_provider.py"],
    "routing-economics.schema.json": ["runtime/external_capability_provider.py"],
    "backend-service-capability.schema.json": ["runtime/backend_capabilities.py"],
}

REASONING_OWNERS = {
    "decision-frontier.schema.json": [
        "runtime/project_reasoning/frontier.py",
        "runtime/cli.py",
    ],
    "glossary-audit.schema.json": [
        "runtime/project_reasoning/glossary_audit.py",
        "runtime/cli.py",
    ],
    "module-depth-audit.schema.json": [
        "runtime/project_reasoning/deep_module_audit.py",
        "runtime/cli.py",
    ],
    "independent-hypothesis-panel.schema.json": ["runtime/reasoning_controls.py"],
    "communication-budget.schema.json": ["runtime/reasoning_controls.py"],
    "specification-lifecycle.schema.json": ["runtime/durable_state.py"],
}

COGNITIVE_OWNERS = {
    "behavioral-delta-certificate.schema.json": ["runtime/behavioral_certification.py"],
    "shadow-behavior-comparison.schema.json": ["runtime/behavioral_certification.py"],
}

KNOWLEDGE_REFINERY_OWNERS = {
    "portable-inventory.schema.json": [
        "runtime/knowledge_refinery.py",
        "runtime/cli.py",
    ],
    "novelty-report.schema.json": ["runtime/knowledge_refinery.py", "runtime/cli.py"],
    "merge-plan.schema.json": ["runtime/knowledge_refinery.py", "runtime/cli.py"],
    "graph-audit.schema.json": ["runtime/knowledge_refinery.py", "runtime/cli.py"],
}

# Every rule below is declared here rather than inherited from the previously published
# registry: a build must be derivable from source alone and must fail closed on a
# contract that has no explicit rule (see tests/test_contract_ownership_registry_source.py).
DECLARED_SUITE_OWNERS = {
    "ai-bom.schema.json",
    "approval.schema.json",
    "assumption.schema.json",
    "claim.schema.json",
    "compatibility-record.schema.json",
    "decision-record.schema.json",
    "evaluation-case.schema.json",
    "evaluation-result.schema.json",
    "failure.schema.json",
    "incident.schema.json",
    "memory-record.schema.json",
    "recovery-plan.schema.json",
    "task-state.schema.json",
    "trace-link.schema.json",
}

COGNITIVE_DIR_OWNERS = {
    "brain-capability.schema.json": (
        "runtime/cognitive_core/index_builder.py",
        "cognitive_runtime_boundary",
    ),
    "cognitive-index.schema.json": (
        "runtime/cognitive_core/index_builder.py",
        "cognitive_runtime_boundary",
    ),
    "formula-definition.schema.json": (
        "runtime/cognitive_core/formula_engine.py",
        "cognitive_runtime_boundary",
    ),
    "reasoning-request.schema.json": (
        "runtime/cognitive_core/facade.py",
        "cognitive_runtime_boundary",
    ),
}

COGNITIVE_DIR_PRODUCERS = {
    "brain-capability.schema.json": ["registry/brain_capabilities.json"],
    "cognitive-index.schema.json": ["scripts/build_cognitive_index.py"],
    "formula-definition.schema.json": ["registry/brain_formulas.json"],
    "reasoning-request.schema.json": ["runtime/cli.py"],
}

OPERATIONS_DIR_OWNERS = {
    "health-model-registry.schema.json": ("runtime/health_model.py", "runtime_control_equivalent"),
    "health-report.schema.json": ("runtime/health_model.py", "runtime_control_equivalent"),
    "operation-event.schema.json": (
        "runtime/operational_visibility.py",
        "runtime_control_equivalent",
    ),
    "os-observer-registry.schema.json": (
        "runtime/operational_observers.py",
        "runtime_control_equivalent",
    ),
    "provider-adapter-registry.schema.json": (
        "runtime/provider_gateway.py",
        "runtime_control_equivalent",
    ),
    "provider-budget-policy.schema.json": (
        "runtime/provider_budget.py",
        "runtime_control_equivalent",
    ),
    "route-observer-registry.schema.json": (
        "runtime/operational_visibility.py",
        "runtime_control_equivalent",
    ),
    "local-model-runtime.schema.json": (
        "runtime/local_model_runtime.py",
        "local_model_lifecycle_runtime_boundary",
    ),
}

OPERATIONS_DIR_PRODUCERS = {
    "health-model-registry.schema.json": ["registry/health_taxonomy.json"],
    "health-report.schema.json": ["runtime/health_model.py"],
    "operation-event.schema.json": ["runtime/operational_visibility.py"],
    "os-observer-registry.schema.json": ["registry/os_observer_registry.json"],
    "provider-adapter-registry.schema.json": ["registry/provider_adapters.json"],
    "provider-budget-policy.schema.json": ["registry/provider_budget_policy.json"],
    "route-observer-registry.schema.json": ["registry/operation_route_registry.json"],
    "local-model-runtime.schema.json": ["runtime/local_model_runtime.py"],
}

OPERATIONS_DIR_TESTS = {
    "health-model-registry.schema.json": "tests/test_health_model.py",
    "health-report.schema.json": "tests/test_health_model.py",
    "operation-event.schema.json": "tests/test_operational_visibility.py",
    "os-observer-registry.schema.json": "tests/test_operational_observers.py",
    "provider-adapter-registry.schema.json": "tests/test_provider_gateway.py",
    "provider-budget-policy.schema.json": "tests/test_provider_budget.py",
    "route-observer-registry.schema.json": "tests/test_operational_visibility.py",
    "local-model-runtime.schema.json": "tests/test_local_model_runtime.py",
}

CONTROL_OWNERS = {
    "certification-readiness.schema.json": (
        "runtime/certification_readiness.py",
        ["runtime/certification_readiness.py", "scripts/bootstrap_certification.py"],
        "runtime_control_equivalent",
        ["tests/test_certification_readiness.py"],
    ),
    "execution-package.schema.json": (
        "runtime/capability_routing.py",
        ["runtime/capability_routing.py"],
        "runtime_enforced",
        ["tests/test_capability_routing.py"],
    ),
    "task-envelope.schema.json": (
        "runtime/capability_routing.py",
        ["runtime/capability_routing.py"],
        "runtime_enforced",
        ["tests/test_capability_routing.py"],
    ),
}


def build(root: Path) -> dict[str, object]:
    records = []
    for path in sorted((root / "contracts").rglob("*.json")):
        relative = path.relative_to(root).as_posix()
        name = path.name
        schema = json.loads(path.read_text(encoding="utf-8"))
        if path.parent.name == "completion":
            owner, enforcement = (
                "runtime/completion_controls.py",
                "completion_control_runtime_boundary",
            )
            producers = ["runtime/completion_controls.py"]
            tests = ["tests/test_completion_controls.py"]
        elif path.parent.name == "knowledge_refinery":
            owner, enforcement = (
                "runtime/knowledge_refinery.py",
                "knowledge_refinery_runtime_boundary",
            )
            producers = KNOWLEDGE_REFINERY_OWNERS[name]
            tests = ["tests/test_knowledge_refinery.py"]
        elif path.parent.name == "cognitive" and name in COGNITIVE_OWNERS:
            producers = COGNITIVE_OWNERS[name]
            owner, enforcement = producers[0], "observable_behavior_runtime_boundary"
            tests = ["tests/test_clean_room_capabilities.py"]
        elif path.parent.name == "reasoning":
            producers = REASONING_OWNERS[name]
            owner, enforcement = producers[0], "engineering_reasoning_runtime_boundary"
            tests = [
                "tests/test_project_reasoning.py",
                "tests/test_clean_room_capabilities.py",
            ]
        elif path.parent.name == "external_capabilities":
            producers = EXTERNAL_CAPABILITY_OWNERS[name]
            owner, enforcement = producers[0], "external_candidate_runtime_boundary"
            tests = [
                "tests/test_external_capability_provider.py",
                "tests/test_clean_room_capabilities.py",
            ]
        elif path.parent.name == "security_capabilities":
            owner, enforcement = (
                "runtime/cybersecurity_provider.py",
                "security_provider_runtime_boundary",
            )
            producers = ["runtime/cybersecurity_provider.py", "runtime/cli.py"]
            tests = ["tests/test_cybersecurity_provider.py"]
        elif path.parent.name == "memory":
            producers = MEMORY_OWNERS[name]
            owner, enforcement = producers[0], "memory_lifecycle_runtime_boundary"
            tests = [
                "tests/test_memory_intelligence.py",
                "tests/test_clean_room_capabilities.py",
            ]
        elif path.parent.name == "learning":
            if name == "shared-contribution.schema.json":
                owner, enforcement = ("runtime/shared_contributions.py", "shared_learning_lineage_runtime_boundary")
                producers = ["runtime/shared_contributions.py", "runtime/learning_promotion.py", "runtime/process_memory.py"]
                tests = ["tests/test_shared_contributions.py"]
            elif name == "verification-record.schema.json":
                owner, enforcement = ("runtime/shared_contributions.py", "shared_learning_verification_runtime_boundary")
                producers = ["runtime/shared_contributions.py", "runtime/learning_promotion.py"]
                tests = ["tests/test_shared_contributions.py"]
            elif name == "observation-pack.schema.json":
                owner, enforcement = ("runtime/observation_projection.py", "evidence_projection_runtime_boundary")
                producers = ["runtime/observation_projection.py", "runtime/evidence_reducer.py", "runtime/memory_intelligence.py"]
                tests = ["tests/test_observation_projection.py", "tests/test_evidence_reducer.py"]
            else:
                raise ValueError(f"learning contract has no ownership rule: {relative}")
        elif path.parent.name == "nsai":
            owner, enforcement = (
                "runtime/nsai_knowledge.py",
                "nsai_single_object_knowledge_boundary",
            )
            producers = [
                "runtime/nsai_knowledge.py",
                "runtime/knowledge_foundry.py",
                "runtime/knowledge_refinery.py",
                "runtime/cognitive_core/index_builder.py",
            ]
            tests = [
                "tests/test_nsai_knowledge.py",
                "tests/test_nsai_knowledge_foundry_materialization.py",
            ]
        elif path.parent.name == "persistent_memory":
            owner, enforcement = (
                "runtime/persistent_memory_provider.py",
                "external_persistent_memory_read_boundary",
            )
            producers = [
                "runtime/persistent_memory_provider.py",
                "runtime/external_capability_provider.py",
            ]
            tests = [
                "tests/test_persistent_memory_provider.py",
                "tests/test_persistent_memory_workflow.py",
            ]
        elif path.parent.name == "transcripts":
            owner, enforcement = (
                "runtime/transcript_analysis.py",
                "transcript_runtime_boundary",
            )
            producers = TRANSCRIPT_OWNERS[name]
            tests = ["tests/test_transcript_analysis.py"]
        elif path.parent.name == "agents":
            producers = AGENT_OWNERS[name]
            owner, enforcement = producers[0], "agent_runtime_boundary"
            tests = [
                "tests/test_agent_provider.py",
                "tests/test_clean_room_capabilities.py",
            ]
        elif path.parent.name == "project_stream":
            owner, enforcement = PROJECT_OWNERS[name]
            producers = [owner]
            tests = [
                "tests/test_contract_runtime.py",
                "tests/test_temp2_completeness.py",
            ]
        elif path.parent.name == "research_ops":
            owner, enforcement = "runtime/research_assimilation.py", "runtime_enforced"
            producers = [
                "runtime/knowledge_foundry.py",
                "runtime/research_assimilation.py",
            ]
            tests = [
                "tests/test_contract_runtime.py",
                "tests/test_research_contract_admission.py",
            ]
        elif name in DECLARED_SUITE_OWNERS:
            owner, enforcement = (
                "runtime/declared_suite.py",
                "declared_suite_runtime_boundary",
            )
            producers = ["builders/declared_suite_support_builder.py"]
            tests = ["tests/test_declared_suite_support.py"]
        elif name in ROOT_OWNERS:
            owner, producers, enforcement, tests = ROOT_OWNERS[name]
        elif name in CONTROL_OWNERS:
            owner, producers, enforcement, tests = CONTROL_OWNERS[name]
        elif path.parent.name == "cognitive":
            owner, enforcement = COGNITIVE_DIR_OWNERS[name]
            producers = COGNITIVE_DIR_PRODUCERS[name]
            tests = ["tests/test_cognitive_core.py"]
        elif path.parent.name == "metacognitive":
            owner, enforcement = (
                "runtime/metacognitive_evolution/facade.py",
                "metacognitive_runtime_boundary",
            )
            producers = ["builders/last_round_assimilation_builder.py"]
            tests = ["tests/test_metacognitive_evolution.py"]
        elif path.parent.name == "scheduling":
            owner, enforcement = (
                "runtime/capability_scheduler.py",
                "scheduling_runtime_boundary",
            )
            producers = ["builders/last_round_assimilation_builder.py"]
            tests = ["tests/test_capability_scheduler.py"]
        elif path.parent.name == "operations":
            owner, enforcement = OPERATIONS_DIR_OWNERS[name]
            producers = OPERATIONS_DIR_PRODUCERS[name]
            tests = [OPERATIONS_DIR_TESTS[name]]
        else:
            raise ValueError(f"contract has no ownership rule: {relative}")
        records.append(
            {
                "path": relative,
                "contract_id": schema.get("$id"),
                "contract_version": "1.0.0",
                "title": schema.get("title", name),
                "owner": owner,
                "producers": producers,
                "consumers": ["runtime/contracts.py"],
                "enforcement": enforcement,
                "packaged": True,
                "tests": list(
                    dict.fromkeys(["tests/test_contract_runtime.py", *tests])
                ),
            }
        )
    return {
        "schema_version": "2.0",
        "policy": "Every shipped schema has one explicit owner and an honest enforcement classification.",
        "contract_count": len(records),
        "records": records,
    }


def dump_result(result: dict[str, object]) -> str:
    '''Canonical serialisation of a build result (sorted records, stable formatting).'''
    ordered = dict(result)
    ordered["records"] = sorted(
        result["records"], key=lambda record: record["path"]  # type: ignore[index]
    )
    return json.dumps(ordered, indent=2) + "\n"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path.cwd())
    args = parser.parse_args()
    root = args.root.resolve()
    result = build(root)
    target = root / "registry" / "contract_ownership.json"
    target.write_text(dump_result(result), encoding="utf-8", newline="\n")
    print(json.dumps({"contract_count": result["contract_count"]}, indent=2))
